<?php
/*
 * Template for displaying 404 not found pages.
 *  
 *  */
get_header();
?>

<div class ="archive-header">
    <h2> <?php esc_html_e( '404: Page not found'); ?> </h2>
<?php get_search_form(); ?>    
</div>

<?php get_sidebar(); ?>
<?php get_footer(); ?>


