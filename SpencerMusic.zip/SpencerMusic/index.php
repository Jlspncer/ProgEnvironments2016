<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href = "style.css" rel = "stylesheet" type= "text/css"/>
	<meta name= "viewport" content= "width=device-width"> 		<!-- Makes the page responsive to it's size -->
    </head>
    <?php get_header(); ?>
    
    <body>
        <div id ="page">
            
            <div id = "nav" > 
            <ul>
            <?php wp_nav_menu('title_li='); ?> <!--This is the wordpress function to generate links -->
            </ul>
            </div> <!--#nav -->
        
            <div id="main">
                <div id="content">
		<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
                <h1><?php the_title(); ?></h1>

                <p><?php the_content(__('(more...)')); ?></p>

                <hr> <?php endwhile; else: ?>

                <p><?php _e('No posts found.'); ?></p><?php
                endif; ?>

                </div> <!-- #content -->
            </div> <!-- #main --> 
        </div><!-- #page -->
</body>   
</html>    

<?php get_sidebar();  ?> 
<?php get_footer(); ?>
