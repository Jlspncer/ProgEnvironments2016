<?php
/** Enable W3 Total Cache */
define('WP_CACHE', true); // Added by W3 Total Cache

/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'admin_spencer');

/** MySQL database username */
define('DB_USER', 'admin_Spencer');

/** MySQL database password */
define('DB_PASSWORD', 'grotto2536');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '=]}B%j=mIu{bUXQSZ1[{zLhQ6hD#}Jlz}1Sgl wdOK_Ra5F;R5y)rHNdBByTKP&a');
define('SECURE_AUTH_KEY',  'v{<wT7#_KVoDQzd8CQXFpLDia|gc:%T#NQt:(bMVwpRF(uJe1`(:Bi=_]*8MIJbQ');
define('LOGGED_IN_KEY',    'B)D6Y#*_zyvD;dj?+2G^Wm>pVE?)+X<WshIj|7k=q2JRP@7;4%c^{%.RP9%Zz(HM');
define('NONCE_KEY',        '&[&BJIB9e9-Y+8dM}p7iy<@B!Rqo`N!Bpcy|9M&r!;?iZsjZI)a@3a:l7,5H>K]1');
define('AUTH_SALT',        '8ejp}e2=1Jsi{.EUts*COK>nP-3o!zM,Do<o#y?NU&ZNn$RoZF:y|oBJ.6@lT6d&');
define('SECURE_AUTH_SALT', 'R>^Gb|aMB=Ucybx5a@Br/YyG|PyWw6#&|F^u,K4%7*A;]L)&Twsog6 7d58nnn4r');
define('LOGGED_IN_SALT',   'y^aLX5sljZ0}k{D4NqP*bSs7(vULNLR2OK1AZIu>0*mL?ZF_!HImb*5zy?kv,m;_');
define('NONCE_SALT',       '9s* 9{F$EidrOUCn.rc]p?ALjy8.4w_eF)pR}qgkocb8n0mK).]9r:;G5,HXe|?q');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
